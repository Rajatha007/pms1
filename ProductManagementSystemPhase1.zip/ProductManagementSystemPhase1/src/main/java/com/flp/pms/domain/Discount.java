package com.flp.pms.domain;

import java.util.Date;

public class Discount 
{
	private int discount_Id;
	private String discount_Name;
	private String description;
	private double discount_percentage;
	private Date validThru;
	
	
	public Discount() {}


	public Discount(int discount_Id, String discount_Name, String discription, double discount_percentage,
			Date validThru) {
		super();
		this.discount_Id = discount_Id;
		this.discount_Name = discount_Name;
		this.description = discription;
		this.discount_percentage = discount_percentage;
		this.validThru = validThru;
	}


	public int getDiscount_Id() {
		return discount_Id;
	}


	public void setDiscount_Id(int discount_Id) {
		this.discount_Id = discount_Id;
	}


	public String getDiscount_Name() {
		return discount_Name;
	}


	public void setDiscount_Name(String discount_Name) {
		this.discount_Name = discount_Name;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String discription) {
		this.description = discription;
	}


	public double getDiscount_percentage() {
		return discount_percentage;
	}


	public void setDiscount_percentage(double discount_percentage) {
		this.discount_percentage = discount_percentage;
	}


	public Date getValidThru() {
		return validThru;
	}


	public void setValidThru(Date validThru) {
		this.validThru = validThru;
	}


	@Override
	public String toString() {
		return "Discount [discount_Id=" + discount_Id + ", discount_Name=" + discount_Name + ", description="
				+ description + ", discount_percentage=" + discount_percentage + ", validThru=" + validThru + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + discount_Id;
		result = prime * result + ((discount_Name == null) ? 0 : discount_Name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(discount_percentage);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((validThru == null) ? 0 : validThru.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Discount other = (Discount) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (discount_Id != other.discount_Id)
			return false;
		if (discount_Name == null) {
			if (other.discount_Name != null)
				return false;
		} else if (!discount_Name.equals(other.discount_Name))
			return false;
		if (Double.doubleToLongBits(discount_percentage) != Double.doubleToLongBits(other.discount_percentage))
			return false;
		if (validThru == null) {
			if (other.validThru != null)
				return false;
		} else if (!validThru.equals(other.validThru))
			return false;
		return true;
	}
	
	
	
	
}
