package com.flp.pms.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplforMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.Sub_Category;
import com.flp.pms.domain.Supplier;
import com.flp.pms.view.BootClass;
import com.flp.pms.view.UserInteraction;

public class ProductServiceImpl implements IProductService

{

	private IProductDao iProductDao = new ProductDaoImplforMap();
	public List<Category> getAllCategory() 
	{
		return iProductDao.getAllCategory();
	}
	public List<Sub_Category> getAllSubCategory() 
	{
		return iProductDao.getAllSubCategory();
		
	}
	public List<Supplier> getAllSupplier() 
	{
		return iProductDao.getAllSuppliers();
	}
	public List<Discount> getAllDiscounts() 
	{
		return iProductDao.getAllDiscounts();
	}
	public void addProduct(Product product)
	{
	
		Map<Integer, Product> maps=iProductDao.getAllProducts();
		boolean flag=false;
		Set<Integer> product_IDS=maps.keySet();
		int product_id_generated=generateProductId();
		
			//Generate unique Product Id
					if(!maps.isEmpty()){
						do{
							product_id_generated=generateProductId();
							for(Integer product_Id:product_IDS){
								if(product_Id==product_id_generated){
									flag=true;
									break;
								}
							}
						}while(flag);
					}
			
			product.setProduct_Id(product_id_generated);
					
					iProductDao.addProduct(product);
				}	
		
	public int generateProductId(){
		return (int)(Math.random()*10000);
	}
	
	public Map<Integer, Product> getAllProducts() 
	{
				return iProductDao.getAllProducts();
	}
	
	public List<Product> viewAllProducts()
	{	
		ArrayList<Product> array = new ArrayList<Product>();
		Iterator entries = ProductDaoImplforMap.products.entrySet().iterator();
		while (entries.hasNext())
		{
			Map.Entry<Integer, Product> print = (Entry<Integer, Product>) entries.next();
			Integer keys = print.getKey();
			Product value = print.getValue();
			array.add(value);
		}
		return array;
	
	}
	
	public boolean removeProduct(int productid) 
	{
		
		ArrayList<Product> array = new ArrayList<Product>();
		for(Iterator<Map.Entry<Integer, Product>> print = ProductDaoImplforMap.products.entrySet().iterator(); 
				print.hasNext();)
		{
			Map.Entry<Integer, Product> ent = print.next();
			Integer keys = ent.getKey();
			Product value = ent.getValue();
			array.add(value);
		}
		for (Product product : array) {
			if (product.getProduct_Id() == UserInteraction.id) 
			{
				if(ProductDaoImplforMap.products.remove(product.getProduct_Id(),product))
					return true ;
			}
		}
		return false;

	
	}
	
	public ArrayList<Product> searchByProductName()
	{
		
		ArrayList<Product> array = new ArrayList<Product>();
	
		for(Iterator<Map.Entry<Integer, Product>> print = ProductDaoImplforMap.products.entrySet().iterator(); 
				print.hasNext();)
		{
			Map.Entry<Integer, Product> ent = print.next();
			if(ent.getValue().getProduct_Name().equalsIgnoreCase(UserInteraction.productName))
			{
				Integer keys = ent.getKey();
				Product value = ent.getValue();
				array.add(value);
				
		}
		}
		return array;
		
	}
	
	public ArrayList<Product> searchBySupplierName()
	{
		
		ArrayList<Product> array = new ArrayList<Product>();
		
		for(Iterator<Map.Entry<Integer, Product>> print = ProductDaoImplforMap.products.entrySet().iterator(); 
				print.hasNext();)
		{
			Map.Entry<Integer, Product> ent = print.next();
			if(ent.getValue().getSupplier().getFirst_Name().equalsIgnoreCase(UserInteraction.supplierName))
			{
				Integer keys = ent.getKey();
				Product value = ent.getValue();
				array.add(value);
				
		}
		}
		return array;
		
	}
	public ArrayList<Product> searchByCategoryName() 
	{
		
		ArrayList<Product> array = new ArrayList<Product>();
		
		for(Iterator<Map.Entry<Integer, Product>> print = ProductDaoImplforMap.products.entrySet().iterator(); 
				print.hasNext();)
		{
			Map.Entry<Integer, Product> ent = print.next();
			if(ent.getValue().getCategory().getCategory_Name().equalsIgnoreCase(UserInteraction.categoryName))
			{
				Integer keys = ent.getKey();
				Product value = ent.getValue();
				array.add(value);
				
		}
		}
		return array;
	}
	public ArrayList<Product> searchBySubCategory()
	{
	
		ArrayList<Product> array = new ArrayList<Product>();
		
		for(Iterator<Map.Entry<Integer, Product>> print = ProductDaoImplforMap.products.entrySet().iterator(); 
				print.hasNext();)
		{
			Map.Entry<Integer, Product> ent = print.next();
			if(ent.getValue().getSub_Category().getSub_Category_Name().equalsIgnoreCase(UserInteraction.sucCategoryName))
			{
				Integer keys = ent.getKey();
				Product value = ent.getValue();
				array.add(value);
				
		}
		}
		return array;
	}
	public ArrayList<Product> searchByRatings()
	{
		
		ArrayList<Product> array = new ArrayList<Product>();
		
		for(Iterator<Map.Entry<Integer, Product>> print = ProductDaoImplforMap.products.entrySet().iterator(); 
				print.hasNext();)
		{
			Map.Entry<Integer, Product> ent = print.next();
			if(ent.getValue().getRatings()==UserInteraction.ratings)
			{
				Integer keys = ent.getKey();
				Product value = ent.getValue();
				array.add(value);
				
		}
		}
		return array;
	}
	
	public boolean validateProductId(int productId)
	{
		
		ArrayList<Product> array = new ArrayList<Product>();
		for(Iterator<Map.Entry<Integer, Product>> print = ProductDaoImplforMap.products.entrySet().iterator(); 
				print.hasNext();)
		{
			Map.Entry<Integer, Product> ent = print.next();
			Integer keys = ent.getKey();
			Product value = ent.getValue();
			array.add(value);
		}
		for (Product product : array) {
			if (product.getProduct_Id() == productId)
			{
					return true ;
			}
		}
		return false;

	}
	
	
		public Map<Integer, Product> updateProductName(int productId,Product p, String pName) 
		{
			Map<Integer, Product> map=getAllProducts();
			
			p.setProduct_Name(pName);
			 map.put(productId, p);
			 System.out.println("Successfully Updated");
			 return map;
	}
		
		public Map<Integer, Product> updateRetailPrice(int productId,Product p, double price) 
		{
			Map<Integer, Product> map=getAllProducts();
			p.setMax_Retail_Prices(price);
			map.put(productId, p);
			System.out.println("Successfully Updated");
			return map;
		}
		
		public Map<Integer, Product> updateExpiryDate(int productId,Product p, Date date) 
		{
			Map<Integer, Product> map=getAllProducts();
			p.setExpiry_Date(date);
			map.put(productId, p);
			System.out.println("Successfully Updated");
			return map;
		}
		public Map<Integer, Product> updateRating(int productId,Product p, float ratings) 
		
		{
			Map<Integer, Product> map=getAllProducts();
			p.setRatings(ratings);
			map.put(productId, p);
			System.out.println("Successfully Updated");
			return map;
		}
		
		public Map<Integer, Product> updateCategory(int productId,Product p, Category category)
		{
			Map<Integer, Product> map=getAllProducts();
			p.setCategory(category);
			map.put(productId, p);
			System.out.println("Successfully Updated");
			return map;
		}
		
}
